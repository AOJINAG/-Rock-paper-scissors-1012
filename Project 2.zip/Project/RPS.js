var aud = document.getElementById("audio_1")
aud.volume = 0.0;