function background1() {
    document.body.style.backgroundImage = "url('rock-paper-scissors.jpg')";
}

function background2() {
    document.body.style.backgroundImage = "url('rock-paper-scissors-2.jpg')";
}

function background3() {
    document.body.style.backgroundImage = "url('rock-paper-scissors-3.jpg')";
}